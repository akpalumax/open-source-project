# snake-game
Snake game with pure javascript. Just for fun!
